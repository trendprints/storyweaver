<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <header>
        <div class="container">
            <h1><a href="<?php echo home_url(); ?>"><?php bloginfo('name'); ?></a></h1>
            <div class="hamburger">
                <div></div>
                <div></div>
                <div></div>
            </div>
            <nav>
                <?php wp_nav_menu(array('theme_location' => 'primary')); ?>
            </nav>
            <label class="theme-toggle">
                <input type="checkbox" id="theme-switch">
                <span class="slider"></span>
            </label>
        </div>
    </header>
    <div class="hero">
        <div class="container">
            <h2><?php bloginfo('description'); ?></h2>
        </div>
    </div>
    <main class="container">