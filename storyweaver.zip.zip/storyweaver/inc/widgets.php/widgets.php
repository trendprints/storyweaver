<?php
function storyweaver_widgets_init() {
    register_sidebar(array(
        'name' => __('Sidebar', 'storyweaver'),
        'id' => 'sidebar-1',
        'description' => __('Add widgets here.', 'storyweaver'),
        'before_widget' => '<section>',
        'after_widget' => '</section>',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));
}
add_action('widgets_init', 'storyweaver_widgets_init');