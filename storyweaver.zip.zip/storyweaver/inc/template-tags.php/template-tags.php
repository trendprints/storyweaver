<?php
function storyweaver_posted_on() {
    $time_string = '<time datetime="%1$s">%2$s</time>';
    printf($time_string, get_the_date(DATE_W3C), get_the_date());
}