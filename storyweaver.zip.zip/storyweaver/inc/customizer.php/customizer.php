<?php
function storyweaver_customizer($wp_customize) {
    $wp_customize->add_section('storyweaver_options', array('title' => __('Theme Options', 'storyweaver')));
    $wp_customize->add_setting('storyweaver_hero_text', array('default' => __('Welcome to StoryWeaver by ArtisnDesigns', 'storyweaver')));
    $wp_customize->add_control('storyweaver_hero_text', array('label' => __('Hero Text', 'storyweaver'), 'section' => 'storyweaver_options', 'type' => 'text'));
}
add_action('customize_register', 'storyweaver_customizer');