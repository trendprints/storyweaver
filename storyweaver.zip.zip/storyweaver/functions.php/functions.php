<?php
/**
 * StoryWeaver functions and definitions
 *
 * @package StoryWeaver
 * @since 1.0
 */

/**
 * Enqueue scripts and styles
 */
function storyweaver_scripts() {
    // Enqueue main stylesheet (style.css)
    wp_enqueue_style( 'storyweaver-style', get_stylesheet_uri(), array(), '1.0' );

    // Enqueue custom CSS (custom.css)
    wp_enqueue_style( 'storyweaver-custom', get_template_directory_uri() . '/assets/css/custom.css', array(), '1.0' );

    // Enqueue main JavaScript (main.js)
    wp_enqueue_script( 'storyweaver-main', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), '1.0', true );

    // Enqueue additional scripts or styles if needed (e.g., for narration or dark mode toggle)
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'storyweaver_scripts' );

/**
 * Theme setup and custom features
 */
function storyweaver_setup() {
    // Make theme available for translation
    load_theme_textdomain( 'storyweaver', get_template_directory() . '/languages' );

    // Add default posts and comments RSS feed links to head
    add_theme_support( 'automatic-feed-links' );

    // Add support for post thumbnails
    add_theme_support( 'post-thumbnails' );

    // Register navigation menus
    register_nav_menus( array(
        'primary' => esc_html__( 'Primary Menu', 'storyweaver' ),
    ) );

    // Add support for HTML5 features
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ) );

    // Add support for custom logo
    add_theme_support( 'custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
        'header-text' => array( 'site-title', 'site-description' ),
    ) );

    // Add support for title tag
    add_theme_support( 'title-tag' );

    // Add support for custom background
    add_theme_support( 'custom-background', array(
        'default-color' => 'f9f9f9',
    ) );

    // Register custom post type for "Stories"
    register_post_type( 'stories', array(
        'labels' => array(
            'name'          => __( 'Stories', 'storyweaver' ),
            'singular_name' => __( 'Story', 'storyweaver' ),
        ),
        'public'        => true,
        'has_archive'   => true,
        'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'menu_icon'     => 'dashicons-book',
    ) );
}
add_action( 'after_setup_theme', 'storyweaver_setup' );

/**
 * Register widget areas
 */
function storyweaver_widgets_init() {
    register_sidebar( array(
        'name'          => esc_html__( 'Sidebar', 'storyweaver' ),
        'id'            => 'sidebar-1',
        'description'   => esc_html__( 'Add widgets here to appear in the sidebar.', 'storyweaver' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'  => '</h2>',
    ) );
}
add_action( 'widgets_init', 'storyweaver_widgets_init' );

/**
 * Add customizer options
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Custom template tags
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom widget functions
 */
require get_template_directory() . '/inc/widgets.php';