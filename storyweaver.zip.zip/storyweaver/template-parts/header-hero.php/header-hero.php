<?php
/**
 * Template part for displaying the hero section
 *
 * @package StoryWeaver
 */

?>

<div class="hero">
    <div class="container">
        <h2><?php bloginfo( 'description' ); ?></h2>
        <?php if ( get_theme_mod( 'storyweaver_hero_text' ) ) : ?>
            <p class="hero-subtitle"><?php echo esc_html( get_theme_mod( 'storyweaver_hero_text' ) ); ?></p>
        <?php endif; ?>
    </div>
</div>