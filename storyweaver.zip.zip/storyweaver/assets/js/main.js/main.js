jQuery(document).ready(function($) {
    $('.hamburger').click(function() {
        $('nav').toggleClass('active');
    });
    $('#theme-switch').change(function() {
        $('body').toggleClass('dark-mode');
        localStorage.setItem('theme', $('body').hasClass('dark-mode') ? 'dark' : 'light');
    });
    if (localStorage.getItem('theme') === 'dark') {
        $('body').addClass('dark-mode');
        $('#theme-switch').prop('checked', true);
    }
    $('.story-card').hover(
        function() { $(this).css('transform', 'translateY(-10px)'); },
        function() { $(this).css('transform', 'translateY(0)'); }
    );
    $('.narration-btn').click(function() {
        var text = $(this).data('text');
        if ('speechSynthesis' in window) {
            var speech = new SpeechSynthesisUtterance(text);
            speech.lang = 'en-US';
            speech.volume = 1;
            speech.rate = 1;
            speech.pitch = 1;
            window.speechSynthesis.cancel();
            if ($(this).text() === 'Listen to Story') {
                window.speechSynthesis.speak(speech);
                $(this).text('Stop Narration');
            } else {
                window.speechSynthesis.cancel();
                $(this).text('Listen to Story');
            }
            speech.onend = function() {
                $('.narration-btn').text('Listen to Story');
            };
        } else {
            alert('Sorry, your browser does not support voice narration.');
        }
    });
});