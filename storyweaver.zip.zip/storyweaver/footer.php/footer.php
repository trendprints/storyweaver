    </main>
    <footer>
        <div class="container">
            <p>© <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. <?php _e('All rights reserved.', 'storyweaver'); ?> | Designed by <a href="https://themeforest.net/user/artisndesigns" target="_blank">ArtisnDesigns</a></p>
        </div>
    </footer>
    <?php wp_footer(); ?>
</body>
</html>