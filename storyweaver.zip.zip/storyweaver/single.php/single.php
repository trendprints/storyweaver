<?php get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <article class="story-card">
        <h2><?php the_title(); ?></h2>
        <div class="post-meta">
            <?php storyweaver_posted_on(); ?> by <?php the_author(); ?>
        </div>
        <?php the_content(); ?>
        <button class="narration-btn" data-text="<?php echo esc_attr(wp_strip_all_tags(get_the_content())); ?>">
            <?php _e('Listen to Story', 'storyweaver'); ?>
        </button>
    </article>
<?php endwhile; endif; ?>
<?php get_footer(); ?>