=================================
StoryWeaver Theme by ArtisnDesigns
=================================

Thank you for choosing StoryWeaver, a premium WordPress theme designed by ArtisnDesigns! This theme is crafted to enhance your storytelling experience with immersive layouts, voice narration, and modern features. Below, you'll find all the necessary information to install, configure, and make the most of your theme.

---

### Table of Contents
1. Theme Overview
2. Requirements
3. Installation
4. Theme Setup
   - 4.1 Configuring Menus
   - 4.2 Setting Up Widgets
   - 4.3 Customizing the Theme
5. Key Features
6. Support & Resources
7. Credits
8. Changelog

---

### 1. Theme Overview
StoryWeaver is a premium storytelling WordPress theme built for bloggers, writers, and content creators. With its immersive design, voice narration functionality, and responsive layouts, it provides a seamless experience for both creators and readers. The theme is fully compatible with WordPress 5.0+ and supports popular plugins like Elementor for enhanced customization.

---

### 2. Requirements
Before installing StoryWeaver, ensure your setup meets the following requirements:
- **WordPress Version**: 5.0 or higher
- **PHP Version**: 7.4 or higher
- **Memory Limit**: At least 256MB (recommended)
- **Plugins (Optional)**:
  - Elementor (for advanced page building)
  - WooCommerce (for e-commerce functionality)
- **Browser Support**: Latest versions of Chrome, Firefox, Safari, Edge

---

### 3. Installation
Follow these steps to install the StoryWeaver theme on your WordPress site:

1. **Upload the Theme**:
   - Log in to your WordPress admin dashboard.
   - Navigate to **Appearance > Themes > Add New**.
   - Click on **Upload Theme** and select the `storyweaver.zip` file from your computer.
   - Click **Install Now**.

2. **Activate the Theme**:
   - Once the theme is uploaded, click **Activate** to enable StoryWeaver on your site.

3. **Verify Installation**:
   - Go to **Appearance > Themes** to confirm that StoryWeaver is the active theme.

---

### 4. Theme Setup
After activating the theme, follow these steps to configure it for your site.

#### 4.1 Configuring Menus
StoryWeaver supports a primary navigation menu. To set it up:
- Go to **Appearance > Menus** in your WordPress dashboard.
- Create a new menu (e.g., "Primary Menu").
- Add your pages, categories, or custom links to the menu.
- In the "Menu Settings" section, assign the menu to the **Primary Menu** location.
- Save the menu.

#### 4.2 Setting Up Widgets
StoryWeaver includes a sidebar widget area for additional functionality:
- Navigate to **Appearance > Widgets**.
- Drag and drop widgets (e.g., Recent Posts, Categories) into the **Sidebar** area.
- Configure widget settings as needed and save.

#### 4.3 Customizing the Theme
StoryWeaver offers customization options via the WordPress Customizer:
- Go to **Appearance > Customize**.
- Modify settings such as:
  - **Site Identity**: Upload a logo and set the site title.
  - **Colors**: Adjust the theme's color scheme.
  - **Theme Options**: Customize the hero section text and other settings.
- Click **Publish** to save your changes.

---

### 5. Key Features
StoryWeaver comes with the following standout features:

- **Voice Narration**:
  - Engage your readers with built-in voice narration. Simply click the "Listen to Story" button on any post to hear the content narrated in a natural voice (supported in modern browsers like Chrome and Firefox).

- **Dark Mode**:
  - Toggle between light and dark modes using the switch in the header. The theme automatically saves the user's preference for a seamless experience.

- **Responsive Design**:
  - StoryWeaver is fully responsive, ensuring your site looks great on all devices—desktops, tablets, and smartphones.

- **Elementor Compatibility**:
  - Build custom layouts effortlessly with Elementor, a popular drag-and-drop page builder.

- **Custom Post Type**:
  - The theme includes a "Stories" custom post type, perfect for organizing storytelling content.

- **Translation Ready**:
  - StoryWeaver is translation-ready with a `languages` folder. Use tools like Loco Translate to translate the theme into your language.

---

### 6. Support & Resources
We’re here to help you make the most of StoryWeaver! For any questions, issues, or customization requests, please reach out:

- **Support Contact**: https://themeforest.net/user/artisndesigns
- **Support Hours**: Monday to Friday, 9 AM to 5 PM (EST)
- **Documentation**: For additional resources, visit our online documentation at https://artisndesigns.com/storyweaver-docs (coming soon).
- **Item Support Policy**: Please review our support policy on ThemeForest for details on what’s included.

**Note**: Support does not cover third-party plugins, custom code modifications, or WordPress core issues. For faster resolution, please provide your purchase code and detailed description of the issue.

---

### 7. Credits
We’d like to thank the following resources that helped make StoryWeaver possible:
- **Fonts**: Roboto by Google Fonts (licensed under Apache License 2.0)
- **Images**: Images used in the demo are from Unsplash (licensed under the Unsplash License). Replace `hero-bg.jpg` with your own image for production use.
- **Libraries**: jQuery (MIT License)

---

### 8. Changelog
**Version 1.0 (March 17, 2025)**:
- Initial release of StoryWeaver theme.

---

Thank you once again for choosing StoryWeaver by ArtisnDesigns! We hope you enjoy using this theme as much as we enjoyed creating it. If you love the theme, please leave a 5-star rating on ThemeForest—it helps us continue creating awesome products for you!

Best regards,  
The ArtisnDesigns Team